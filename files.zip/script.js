var s = 5, b = 0, found = new Set();

var inv = {};

var S = {
living: {
  text: "Ruang tamu berbau debu dan melati. Televisi yang mati menyala sendiri, menampilkan semut hitam putih yang bergerak seperti kerumunan wajah. Di meja, telepon rumah berdering. Kabelnya tidak terpasang.\n\nDi bawah pesawat telepon ada kunci kecil berkarat.",
  choices: [
    ["Angkat telepon", "phone", -1, 1],
    ["Ambil kunci kecil", "hall", 0, 0, 0, {give: "kunci"}],
    ["Kembali ke lorong", "hall"]
  ]
},
phone: {
  text: "Dari gagang telepon terdengar tangisan. Itu suaramu sendiri, bergetar, memanggil “Ibu… Ibu…” dari tempat yang gelap dan sempit.\n\nLalu hening, dan suara Ibu terdengar sangat dekat di telingamu.\n\n“Sabar, Nak. Sebentar lagi.”",
  choices: [["Letakkan telepon dan keluar", "hall"]]
},
nursery: {
  text: "Tangga loteng berderit di setiap injakan. Kamar bermain itu penuh boneka yang duduk menghadap pintu. Sebuah ayunan kecil bergoyang tanpa angin, dan tawa anak-anak bergema dari dalam lemari mainan.\n\nSalah satu boneka tidak punya mata, tapi kepalanya mengikuti setiap gerakanmu.",
  choices: [
    ["Cari asal tawa di lemari mainan", "end_scare", 0, 0, 0, {ghost: "tuyul"}],
    ["Turun pelan-pelan", "hall", -1, 0]
  ]
},
drawer: {
  text: "Kunci kecil itu pas. Di dalam laci ada sebuah foto: kamu, sekitar tujuh tahun, digendong Ibu di depan rumah ini. Senyum Ibu di foto itu senyum manusia biasa, dan matanya basah.\n\nDi baliknya tertulis: “Anakku. Jangan lupa jalan pulang.”\n\nLampu kamar berkedip, dan sesuatu di balik pintu lemari bergeser.",
  choices: [["Simpan foto dan mundur", "room"]]
},
title: {
  text: "Pilihanmu menentukan ke mana malam ini berakhir.\n\nKewarasanmu bisa habis. Ibu bisa semakin erat menggenggammu. Tidak ada akhir yang benar-benar baik di rumah ini, hanya akhir yang masih bisa kamu tanggung.\n\nPerhatian: ada suara dan gambar yang muncul mendadak. Kecilkan volume bila perlu.",
  choices: [["Mulai", "start"]]
},
start: {
  text: "Pukul 02.14. Ponselmu bergetar di atas meja. Layarnya hanya menulis: Rumah.\n\nKamu mengangkatnya. Suara itu lembut, terlalu lembut, dan kamu mengenalnya lebih baik daripada suaramu sendiri.\n\n“Pulang, Nak. Makan malamnya sudah dingin.”\n\nDi sela kata-katanya terdengar bunyi basah, seperti seseorang membuka mulut terlalu lebar. Ibu dimakamkan tiga tahun lalu.",
  choices: [
    ["Jawab: “Iya, Bu. Aku pulang.”", "gate", -1, 2],
    ["Matikan telepon, tapi tetap berangkat", "gate", 0, 0]
  ]
},
gate: {
  text: "Hujan turun saat kamu tiba. Hanya lampu dapur yang menyala, kuning dan hangat, seperti dulu setiap kamu pulang terlambat.\n\nDi jendela lantai atas, tirai bergerak. Ada sesuatu berdiri di baliknya, terlalu tinggi untuk ukuran ibumu.\n\nPintu depan tidak terkunci. Di keset ada sandal rumahmu, masih basah.",
  choices: [
    ["Masuk lewat pintu depan", "hall"],
    ["Intip dari jendela dapur dulu", "window", -1, 0]
  ]
},
window: {
  text: "Lewat kaca berembun kamu melihat Ibu berdiri di depan kompor, membelakangimu. Lehernya miring ke samping, seperti patah, dan ia menyenandungkan lagu yang tidak punya nada.\n\nKepalanya berputar pelan menghadapmu, sementara badannya tetap diam. Ia tidak berkedip. Sudut bibirnya naik hampir sampai ke telinga.\n\n“Jangan mengintip, sayang. Masuklah.”",
  choices: [["Masuk lewat pintu depan", "hall", 0, 1]]
},
hall: {
  text: "Lorong dipenuhi foto keluarga. Di foto-foto dekat pintu, Ibu menatap kamera. Semakin ke dalam, tatapannya bergeser, dan di foto terakhir ia menatap lurus ke arahmu, dengan mulut terbuka sedikit lebih lebar di setiap bingkai.\n\nDari dapur terdengar dua piring diletakkan di meja. Di lantai atas, pintu kamar masa kecilmu berderit. Dari balik pintu ruang bawah tanah yang selalu dikunci Ibu, terdengar sesuatu menggaruk kayu. Di ruang tamu telepon berdering pelan, dan dari loteng terdengar tawa anak-anak.",
  choices: [
    ["Ke dapur", "kitchen"],
    ["Masuk ruang tamu", "living"],
    ["Naik ke kamarmu", "room"],
    ["Naik ke loteng, ke arah suara tawa", "nursery", -1, 0],
    ["Buka pintu ruang bawah tanah", "cellar", -1, 0]
  ]
},
kitchen: {
  text: "Ibu duduk di kepala meja, punggungnya terlalu lurus dan kulitnya sewarna lilin. Bau melati dan tanah basah menguar dari tubuhnya. Rambutnya disanggul seperti hari terakhir.\n\n“Makan, Nak. Kamu kurus sekali. Ibu tidak tenang kalau kamu belum makan.”\n\nTelur dadar di piringmu mengeluarkan uap. Di bawahnya ada seuntai rambut hitam panjang. Bibir Ibu tidak bergerak saat bicara.",
  choices: [
    ["Makan", "eat", -1, 2],
    ["“Bu, Ibu sudah meninggal.”", "confront", 1, -2],
    ["Pamit ke kamar kecil, lalu naik ke kamarmu", "room"],
    ["Sentuh wajah Ibu untuk memastikan", "end_scare", 0, 0, 0, {ghost: "ibu"}]
  ]
},
eat: {
  text: "Rasanya persis seperti masa kecilmu, dan itu yang paling menakutkan. Semakin banyak kamu makan, semakin sedikit kamu ingat kenapa kamu datang.\n\nSaat kamu mengunyah, rahang Ibu turun pelan, jauh lebih rendah dari yang mungkin, dan suara itu keluar dari sana.\n\n“Anak baik. Tinggal ya, malam ini. Malam-malam berikutnya juga.”\n\nPiringmu tidak pernah habis.",
  choices: [
    ["Taruh sendok dan menatapnya", "confront", 1, -1],
    ["Terus makan, lalu mengangguk", "truth", -1, 2]
  ]
},
confront: {
  text: "Senyum Ibu tidak berubah. Hanya matanya yang bergerak, pelan, ke arah tanganmu, lalu ke lehermu.\n\n“Ibu tidak pernah pergi. Ibu menunggumu di sini. Kamu yang tidak pulang-pulang.”\n\nLampu dapur berkedip. Jam dinding berhenti di 02.14. Kamu baru sadar, tidak ada satu pun jam di rumah ini yang berdetak.",
  choices: [
    ["Naik ke kamarmu", "room"],
    ["Turun ke ruang bawah tanah", "cellar", -1, 0]
  ]
},
room: {
  text: "Kamarmu rapi, seprainya baru disetrika. Di meja ada buku harianmu. Entri terakhir ditulis dengan tulisan tanganmu, tapi kamu tidak ingat pernah menulisnya:\n\n“Ibu menangis di samping ranjangku. Kata dokter aku tidak akan bangun lagi. Ibu bilang, kalau Ibu terus memanggilku, aku pasti pulang.”\n\nDi cermin lemari ada Ibu, berdiri di belakang ranjang, kepalanya hampir menyentuh langit-langit. Padahal di kamar ini tidak ada siapa-siapa. Kamu juga tidak ada di cermin itu.",
  choices: [
    ["Tatap cermin lebih lama", "mirror", -1, 0],
    ["Buka laci meja dengan kunci kecil", "drawer", -1, 0, 0, {need: "kunci", give: "foto"}],
    ["Buka lemari pakaian", "end_scare", 0, 0, 0, {ghost: "kuntilanak"}],
    ["Turun mencari kebenaran", "cellar"]
  ]
},
mirror: {
  text: "Bayangan Ibu mendekat. Jari-jarinya panjang, bersendi terlalu banyak, dan menyentuh pundak yang tidak ada di cermin. Di pundakmu sendiri, kamu merasakan dingin yang menekan.\n\n“Kamu kedinginan,” bisiknya. “Ibu hangatkan.”\n\nPelan-pelan rasa takutmu mengendur. Kamu mulai lupa kenapa kamu takut.",
  choices: [
    ["Biarkan Ibu memeluk", "truth", -1, 2],
    ["Tarik diri dan turun ke bawah", "cellar", 0, -1]
  ]
},
cellar: {
  text: "Tangga bawah tanah berbau tanah basah dan melati. Di dindingnya tertempel ratusan kertas, catatan telepon yang dibuat Ibu setiap malam pukul 02.14. Nomor yang ia hubungi selalu nomormu.\n\nDi ujung ruangan ada batu nisan kecil, bersih dan dirawat. Namamu terukir di sana, dengan tanggal tiga tahun lalu. Di sampingnya ada peti kayu panjang, tutupnya tergores dari dalam.\n\nDi belakangmu, Ibu menuruni tangga tanpa suara. Kepalanya muncul lebih dulu, miring, hampir menyentuh lantai.",
  choices: [
    ["Berbalik menghadapinya", "truth"],
    ["Buka peti di samping nisan", "end_scare", 0, 0, 0, {ghost: "pocong"}]
  ]
},
truth: {
  text: "“Maafkan Ibu,” katanya. Suaranya pecah, dan untuk pertama kalinya terdengar seperti manusia. Kulit wajahnya mengelupas seperti lilin yang meleleh, dan di baliknya ada sesuatu yang gelap dan lapar. “Ibu cuma tidak mau sendirian. Ibu tahu ini salah.”\n\nDinding rumah ini bernapas, lampu-lampunya mengikuti napas Ibu. Pintu depan terbuka di ujung lorong. Hujan di luar sudah berhenti.\n\nKeputusan terakhir ada di tanganmu.",
  choices: [
    ["Tunjukkan foto itu dan sebut namamu sendiri", "end_open", 0, 0, 0, {need: "foto"}],
    ["Peluk Ibu dan tinggal", "end_stay"],
    ["“Aku sayang Ibu. Ibu boleh melepaskanku.”", function () { return s < 3 ? "end_mad" : (b < 1 ? "end_loop" : "end_open"); }],
    ["Lari ke pintu", "end_scare", 0, 0, 0, {ghost: "kuntilanak"}]
  ]
},
end_stay: {
  end: true, title: "Anak yang Pulang",
  text: "Pelukannya sedingin lantai, dan lengannya terus melingkar jauh lebih panjang dari yang seharusnya. Sesuatu mengisi mulutmu: melati dan tanah. Kamu tidak lagi mendengar hujan, tidak lagi mengingat nama-nama.\n\nDi ruang bawah tanah, ada nisan kedua yang belum diberi nama.\n\nIbu masih menelepon setiap pukul 02.14. Kini bukan hanya kamu yang ia panggil pulang.",
  choices: [["Main lagi", "title", 0, 0, true]]
},
end_mad: {
  end: true, title: "Anak yang Baik",
  text: "Kamu tidak lagi bisa membedakan suaramu dari suara Ibu. Kalimat-kalimat keluar dari mulutmu tanpa kamu tahu dari mana asalnya.\n\n“Makan, Nak. Kamu kurus sekali.”\n\nKepalamu miring ke satu sisi, dan kamu tersenyum terlalu lebar. Di meja ada dua piring. Kamu duduk di kepala meja, menunggu anakmu pulang.",
  choices: [["Main lagi", "title", 0, 0, true]]
},
end_loop: {
  end: true, title: "Pukul 02.14",
  text: "Ibu menatapmu lama, tanpa berkedip. “Kamu bilang begitu setiap malam,” katanya, lalu menjentikkan jarinya.\n\nKamu terbangun di kursi. Ponselmu bergetar. Layarnya menulis: Rumah.\n\n“Pulang, Nak. Makan malamnya sudah dingin.”\n\nMalam ini bukan yang pertama.",
  choices: [["Main lagi", "title", 0, 0, true]]
},
end_scare: {
  end: true, scare: true, title: "Wajah yang Dipakai",
  text: "Gelap. Yang kamu lihat tadi bukan Ibu. Itu hanya wajah yang ia pakai supaya kamu mau pulang.\n\nTetangga bilang rumah itu kosong sejak tiga tahun lalu. Tapi sampai pagi, mereka masih mendengar pintu yang dikunci dari dalam, dan seseorang menyenandungkan lagu pengantar tidur dengan suara yang bukan suara siapa pun.\n\nLampu dapurnya tidak pernah padam.",
  choices: [["Main lagi", "title", 0, 0, true]]
},
end_open: {
  end: true, title: "Pagi yang Tidak Pasti",
  text: "Ibu melepaskanmu. Tangannya gemetar, dan kulitnya runtuh menjadi abu di antara jari-jarimu. Kamu melangkah ke pintu tanpa menoleh.\n\nLangit memutih. Di ponselmu ada satu panggilan tak terjawab: Rumah, 02.14.\n\nKamu tidak tahu apakah kamu berjalan menjauhi rumah itu, atau hanya berjalan di dalam mimpi Ibu yang lebih luas. Di belakangmu, lampu dapur masih menyala. Kamu belum berani menoleh.",
  choices: [["Main lagi", "title", 0, 0, true]]
}
};

var AL = {window: "title", gate: "title", eat: "kitchen", confront: "kitchen", drawer: "room", mirror: "room", end_stay: "cellar", end_loop: "living", end_mad: "kitchen", end_open: "dawn"};
var R = '<rect width="320" height="150" fill="#1b1311"/><rect y="112" width="320" height="38" fill="#0e0908"/>';
var ART = {
title: '<rect width="320" height="150" fill="#0d0a0c"/><circle cx="262" cy="30" r="14" fill="#cfc6b4" opacity=".7"/><path d="M90 150V80L160 40L230 80V150Z" fill="#171011"/><path d="M80 82L160 34L240 82" stroke="#2a1a1a" stroke-width="4" fill="none"/><rect x="142" y="96" width="24" height="30" fill="#d2ad5c" class="fl"/><rect x="190" y="62" width="14" height="20" fill="#080505"/><path d="M0 138H320V150H0Z" fill="#050303"/><path d="M30 0l-8 26M70 12l-8 26M120 0l-8 26M200 8l-8 26M250 0l-8 26M290 14l-8 26" stroke="#3a4046" stroke-width="1"/>',
hall: R + '<g fill="#2a1d1a" stroke="#4a3a34" stroke-width="2"><rect x="28" y="28" width="38" height="50"/><rect x="84" y="28" width="38" height="50"/><rect x="140" y="28" width="38" height="50"/></g><g fill="#cfc6b4"><ellipse cx="47" cy="52" rx="10" ry="13"/><ellipse cx="103" cy="52" rx="10" ry="13"/><ellipse cx="159" cy="52" rx="10" ry="13"/></g><path d="M41 58q6 4 12 0M97 58q6 8 12 0M151 58q8 12 16 0" stroke="#000" stroke-width="2" fill="none"/><rect x="240" y="36" width="52" height="76" fill="#070404"/><circle cx="282" cy="76" r="2" fill="#d2ad5c"/>',
kitchen: R + '<circle cx="160" cy="24" r="30" fill="#d2ad5c" fill-opacity=".16" class="fl"/><path d="M160 0V18" stroke="#3a2a22"/><rect x="60" y="94" width="190" height="8" fill="#3a2a22"/><rect x="70" y="102" width="6" height="40" fill="#2a1c16"/><rect x="234" y="102" width="6" height="40" fill="#2a1c16"/><ellipse cx="110" cy="92" rx="16" ry="4" fill="#cfc6b4"/><ellipse cx="170" cy="92" rx="16" ry="4" fill="#cfc6b4"/><path d="M262 112Q282 66 302 112Z" fill="#cfc6b4"/><g transform="rotate(16 282 60)"><ellipse cx="282" cy="58" rx="13" ry="17" fill="#d9d2c2"/><circle cx="282" cy="38" r="7" fill="#050303"/></g>',
room: R + '<rect x="30" y="88" width="120" height="24" fill="#3a2430"/><rect x="30" y="72" width="20" height="40" fill="#2b1a22"/><rect x="196" y="18" width="68" height="94" fill="#120c0c" stroke="#4a3a34" stroke-width="3"/><rect x="204" y="26" width="52" height="78" fill="#242a2c"/><ellipse cx="230" cy="44" rx="7" ry="9" fill="#cfc6b4"/><rect x="224" y="52" width="12" height="50" fill="#cfc6b4" opacity=".75"/><rect x="278" y="92" width="26" height="20" fill="#3a2a22"/>',
cellar: '<rect width="320" height="150" fill="#090606"/><path d="M0 0H90V12H72V28H54V44H36V60H18V76H0Z" fill="#1d1513"/><path d="M134 112V82Q134 64 152 64Q170 64 170 82V112Z" fill="#6b6258"/><path d="M144 82h16M144 92h16" stroke="#3a342e" stroke-width="2"/><path d="M200 112L212 82H292L304 112Z" fill="#3a2418" stroke="#1a0f0a"/><path d="M232 92l10 14M246 90l8 16M260 92l6 12" stroke="#a08066" stroke-width="2"/><rect y="112" width="320" height="38" fill="#050303"/><circle cx="108" cy="104" r="3" fill="#d2ad5c" class="fl"/>',
truth: '<rect width="320" height="150" fill="#120c0c"/><rect x="128" y="18" width="64" height="104" fill="#cfc6b4" opacity=".85"/><path d="M128 122H192L230 150H90Z" fill="#cfc6b4" opacity=".3"/><g transform="rotate(10 160 40)"><path d="M160 30Q148 40 150 60L140 122H180L170 60Q172 40 160 30Z" fill="#050303"/></g>',
living: R + '<rect x="30" y="80" width="92" height="32" fill="#2d1c1c"/><rect x="30" y="66" width="92" height="16" fill="#3a2424"/><rect x="146" y="40" width="46" height="36" fill="#3d4448" class="fl"/><rect x="206" y="88" width="56" height="24" fill="#3a2a22"/><path d="M216 88q18-16 36 0" stroke="#111" stroke-width="6" fill="none"/>',
phone: R + '<rect x="120" y="84" width="80" height="28" fill="#3a2a22"/><path d="M134 84q26-26 52 0" stroke="#111" stroke-width="7" fill="none"/><circle cx="160" cy="98" r="8" fill="#111"/>',
nursery: R + '<path d="M36 82H116V112H36Z" fill="none" stroke="#6a5a52" stroke-width="3"/><path d="M52 82v30M68 82v30M84 82v30M100 82v30" stroke="#6a5a52" stroke-width="2"/><circle cx="160" cy="100" r="9" fill="#cfc6b4"/><circle cx="190" cy="102" r="8" fill="#cfc6b4"/><path d="M155 98h4M165 98h4M186 100h4" stroke="#000" stroke-width="2"/><ellipse cx="270" cy="96" rx="11" ry="14" fill="#cfc6b4"/><circle cx="266" cy="95" r="3.5" fill="#000"/><circle cx="275" cy="95" r="3.5" fill="#000"/>',
dawn: '<rect width="320" height="100" fill="#a9a29b"/><rect y="100" width="320" height="50" fill="#3a3430"/><path d="M200 100V80L230 62L260 80V100Z" fill="#1a1412"/><rect x="224" y="82" width="10" height="12" fill="#d2ad5c"/><path d="M60 150L120 100" stroke="#5a504a" stroke-width="10"/>'
};
AL.phone = "phone";

function art(key) {
  var a = ART[AL[key] || key];
  return a ? '<div class="art"><svg viewBox="0 0 320 150" aria-hidden="true">' + a + "</svg></div>" : "";
}

function G(x) { return '<svg viewBox="0 0 200 240" aria-hidden="true">' + x + "</svg>"; }
var GHOST = {
ibu: G('<path d="M28 125C14 15 186 15 172 125L168 240H32Z" fill="#050303"/><ellipse cx="100" cy="122" rx="60" ry="84" fill="#cfc6b4"/><ellipse cx="74" cy="104" rx="18" ry="28" fill="#000"/><ellipse cx="126" cy="104" rx="18" ry="28" fill="#000"/><circle cx="74" cy="104" r="2.5" fill="#fff"/><circle cx="126" cy="104" r="2.5" fill="#fff"/><path d="M38 152Q100 250 162 152Q100 188 38 152Z" fill="#150202"/><path d="M42 153Q100 190 158 153" fill="none" stroke="#e8e0d0" stroke-width="3" stroke-dasharray="3 4"/>'),
kuntilanak: G('<path d="M40 0H160L192 240H8Z" fill="#050303"/><path d="M60 150Q100 130 140 150L172 240H28Z" fill="#e8e2d6"/><ellipse cx="100" cy="95" rx="38" ry="52" fill="#d9d2c2"/><path d="M62 52Q100 92 70 150M138 52Q100 92 130 150" stroke="#050303" stroke-width="7" fill="none"/><ellipse cx="84" cy="96" rx="8" ry="13" fill="#000"/><ellipse cx="116" cy="96" rx="8" ry="13" fill="#000"/><path d="M84 110v44M116 110v44" stroke="#8a1010" stroke-width="3"/><path d="M78 132Q100 182 122 132Q100 150 78 132Z" fill="#6a0a0a"/>'),
pocong: G('<path d="M100 4L88 30H112Z" fill="#d8d0bd"/><path d="M58 44Q100 0 142 44V232H58Z" fill="#e0d8c4"/><ellipse cx="100" cy="72" rx="27" ry="33" fill="#17110d"/><circle cx="89" cy="66" r="6" fill="#c01212"/><circle cx="111" cy="66" r="6" fill="#c01212"/><path d="M86 90Q100 104 114 90" stroke="#6a0a0a" stroke-width="3" fill="none"/><path d="M58 120H142M58 176H142" stroke="#8a7a5a" stroke-width="4"/><path d="M80 132l6 22M120 152l4 26M96 190l5 30" stroke="#6a4a2a" stroke-width="4"/>'),
tuyul: G('<ellipse cx="100" cy="128" rx="64" ry="72" fill="#a9b09a"/><ellipse cx="34" cy="124" rx="10" ry="18" fill="#a9b09a"/><ellipse cx="166" cy="124" rx="10" ry="18" fill="#a9b09a"/><ellipse cx="74" cy="118" rx="21" ry="27" fill="#000"/><ellipse cx="126" cy="118" rx="21" ry="27" fill="#000"/><circle cx="80" cy="108" r="4" fill="#fff"/><circle cx="132" cy="108" r="4" fill="#fff"/><path d="M52 166Q100 222 148 166Q100 182 52 166Z" fill="#200505"/><path d="M58 169l8 11 8-11 8 11 8-11 8 11 8-11 8 11 8-11 8 11 8-11" stroke="#e8e0d0" stroke-width="3" fill="none"/>')
};

function warp(p) {
  if (s > 2) return p;
  return p.split(" ").map(function (w, i) {
    return (w.length > 3 && (i * 5 + p.length) % 9 === 0) ? "Ibu" : w;
  }).join(" ");
}

function show(key) {
  var sc = S[key], el = document.getElementById("story"), h = "";
  document.body.classList.toggle("low", s <= 2 && !sc.end && key !== "title");
  document.getElementById("stats").hidden = (key === "title");
  document.getElementById("inv").textContent = "Barang: " + (Object.keys(inv).join(", ") || "kosong");
  document.getElementById("ki").style.width = (s / 5 * 100) + "%";
  document.getElementById("bi").style.width = (b / 5 * 100) + "%";
  h += art(key);
  if (key === "title") h += '<h1 class="title">Mother</h1>';
  if (sc.end) { found.add(key); h += "<h2>" + sc.title + "</h2>"; }
  var paras = sc.text.split("\n\n");
  paras.forEach(function (p, i) {
    h += '<p class="' + (p.charAt(0) === "“" ? "say" : "") + '" style="--n:' + i + '">' + warp(p) + "</p>";
  });
  if (sc.end) h += '<p class="dim" style="--n:' + paras.length + '">Akhir yang sudah kamu temukan: ' + found.size + " dari 5</p>";
  h += '<div class="choices" style="--d:' + ((paras.length + (sc.end ? 1 : 0)) * 0.9 + 0.2) + 's">';
  sc.choices.forEach(function (c, i) { if (c[5] && c[5].need && !inv[c[5].need]) return; h += '<button data-i="' + i + '">' + c[0] + "</button>"; });
  h += "</div>";
  el.innerHTML = h;
  el.onclick = function (e) {
    var btn = e.target.closest("button");
    if (btn) pick(sc.choices[+btn.dataset.i]);
  };
  window.scrollTo(0, 0);
}

function scream() {
  try {
    var A = new (window.AudioContext || window.webkitAudioContext)();
    var n = A.createBuffer(1, A.sampleRate * 1.2, A.sampleRate), d = n.getChannelData(0);
    for (var i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 1.5);
    var src = A.createBufferSource(); src.buffer = n;
    var f = A.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = 1800;
    var g = A.createGain(); g.gain.value = 0.9;
    src.connect(f); f.connect(g); g.connect(A.destination); src.start();
    var o = A.createOscillator(); o.type = "sawtooth";
    o.frequency.setValueAtTime(900, A.currentTime);
    o.frequency.exponentialRampToValueAtTime(120, A.currentTime + 1);
    var og = A.createGain(); og.gain.value = 0.25;
    o.connect(og); og.connect(A.destination); o.start(); o.stop(A.currentTime + 1);
  } catch (e) {}
}

function jumpscare(g, cb) {
  var st = document.getElementById("story"), j = document.getElementById("js");
  st.style.visibility = "hidden";
  setTimeout(function () {
    scream(); j.innerHTML = GHOST[g] || GHOST.ibu; j.hidden = false;
    setTimeout(function () { j.hidden = true; st.style.visibility = ""; cb(); }, 1600);
  }, 900);
}

function pick(c) {
  if (c[4]) { s = 5; b = 0; inv = {}; }
  s = Math.max(0, Math.min(5, s + (c[2] || 0)));
  b = Math.max(0, Math.min(5, b + (c[3] || 0)));
  if (c[5] && c[5].give) inv[c[5].give] = 1;
  var t = typeof c[1] === "function" ? c[1]() : c[1];
  if (s <= 0 && !S[t].end) t = "end_mad";
  if (S[t].scare) { jumpscare(c[5] && c[5].ghost, function () { show(t); }); } else { show(t); }
}

show("title");
